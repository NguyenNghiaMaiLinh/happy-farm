export const blogs = [
  {
    id: 1,
    slug: "phan-huu-co-va-phan-vo-co",
    category: "Phân bón",
    title: "Phân hữu cơ và phân vô cơ: Sử dụng đúng cách cho cây trồng",
    description:
      "So sánh ưu điểm, nhược điểm và cách kết hợp phân hữu cơ với phân vô cơ để cây phát triển bền vững.",
    image:
      "https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&w=1200&q=80",
    date: "30/07/2026",
    author: "Happy Farm",
    readTime: "8 phút đọc",
    featured: true,
  },

  {
    id: 2,
    slug: "dat-sach-la-gi",
    category: "Đất sạch",
    title: "Đất sạch là gì? Cách chọn đất sạch phù hợp từng loại cây",
    description:
      "Tìm hiểu thành phần của đất sạch, ưu điểm và cách chọn đúng loại đất cho rau, hoa và cây ăn trái.",
    image:
      "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=1200&q=80",
    date: "28/07/2026",
    author: "Happy Farm",
    readTime: "7 phút đọc",
    featured: true,
  },

  {
    id: 3,
    slug: "trong-rau-ban-cong",
    category: "Trồng rau",
    title: "Kinh nghiệm trồng rau ban công cho người mới bắt đầu",
    description:
      "Những bước cơ bản giúp bạn tạo một khu vườn xanh ngay tại ban công.",
    image:
      "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&w=1200&q=80",
    date: "25/07/2026",
    author: "Happy Farm",
    readTime: "10 phút đọc",
    featured: false,
  },

  {
    id: 4,
    slug: "cach-phoi-tron-gia-the",
    category: "Giá thể",
    title: "Cách phối trộn giá thể giúp cây phát triển mạnh",
    description:
      "Tỷ lệ phối trộn xơ dừa, trấu hun, perlite và phân hữu cơ cho từng loại cây.",
    image:
      "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=1200&q=80",
    date: "22/07/2026",
    author: "Happy Farm",
    readTime: "9 phút đọc",
    featured: false,
  },

  {
    id: 5,
    slug: "phan-bo-hoai-muc",
    category: "Phân bón",
    title: "Phân bò hoai mục có tốt không?",
    description:
      "Hướng dẫn sử dụng phân bò đã ủ hoai đúng cách để cải tạo đất và nuôi cây.",
    image:
      "https://images.unsplash.com/photo-1492496913980-501348b61469?auto=format&fit=crop&w=1200&q=80",
    date: "20/07/2026",
    author: "Happy Farm",
    readTime: "6 phút đọc",
    featured: false,
  },

  {
    id: 6,
    slug: "he-thong-tuoi-nho-giot",
    category: "Thiết kế",
    title: "Hệ thống tưới nhỏ giọt cho ban công và sân thượng",
    description:
      "Giải pháp tiết kiệm nước, tiết kiệm thời gian và giúp cây phát triển đồng đều.",
    image:
      "https://images.unsplash.com/photo-1473448912268-2022ce9509d8?auto=format&fit=crop&w=1200&q=80",
    date: "18/07/2026",
    author: "Happy Farm",
    readTime: "8 phút đọc",
    featured: false,
  },
];