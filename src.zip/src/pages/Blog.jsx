import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import BlogCard from "../components/BlogCard/BlogCard";
import { blogs } from "../data/blogs";

function Blog() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Tất cả");

  const categories = [
    "Tất cả",
    "Đất sạch",
    "Giá thể",
    "Phân bón",
    "Trồng rau",
    "Thiết kế",
  ];

  const filteredBlogs = useMemo(() => {
    return blogs.filter((blog) => {
      const matchCategory =
        category === "Tất cả" || blog.category === category;

      const matchSearch =
        blog.title.toLowerCase().includes(search.toLowerCase()) ||
        blog.description.toLowerCase().includes(search.toLowerCase());

      return matchCategory && matchSearch;
    });
  }, [search, category]);

  const featured = blogs[0];

  return (
    <main className="bg-gray-50 min-h-screen">

      {/* Hero */}
      <section className="bg-gradient-to-r from-green-700 to-green-600 py-24 text-white">
        <div className="container mx-auto px-4 text-center">

          <span className="inline-block rounded-full bg-white/20 px-4 py-2 text-sm">
            🌿 Happy Farm Academy
          </span>

          <h1 className="mt-6 text-5xl font-bold">
            Kiến thức nông nghiệp
          </h1>

          <p className="mx-auto mt-6 max-w-3xl text-lg text-green-100">
            Chia sẻ kinh nghiệm trồng cây, đất sạch, giá thể,
            phân bón và thiết kế ban công xanh.
          </p>

          <div className="mx-auto mt-10 flex max-w-xl items-center rounded-2xl bg-white px-5 py-4 shadow-xl">
            <Search className="text-gray-400" size={22} />

            <input
              type="text"
              placeholder="Tìm kiếm bài viết..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="ml-3 w-full border-none bg-transparent outline-none text-gray-700"
            />
          </div>
        </div>
      </section>

      {/* Featured */}
      {featured && (
        <section className="container mx-auto px-4 py-16">
          <div className="overflow-hidden rounded-3xl bg-white shadow-xl lg:grid lg:grid-cols-2">

            <img
              src={featured.image}
              alt={featured.title}
              className="h-full w-full object-cover"
            />

            <div className="flex flex-col justify-center p-10">

              <span className="mb-4 inline-block rounded-full bg-green-100 px-4 py-2 text-sm font-semibold text-green-700">
                {featured.category}
              </span>

              <h2 className="text-4xl font-bold">
                {featured.title}
              </h2>

              <p className="mt-6 text-gray-600">
                {featured.description}
              </p>

              <div className="mt-8 flex gap-6 text-sm text-gray-500">
                <span>{featured.date}</span>
                <span>{featured.readTime}</span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      <section className="container mx-auto px-4">

        <div className="flex flex-wrap gap-3">

          {categories.map((item) => (
            <button
              key={item}
              onClick={() => setCategory(item)}
              className={`rounded-full px-5 py-2 font-medium transition ${
                category === item
                  ? "bg-green-700 text-white"
                  : "bg-white text-gray-700 hover:bg-green-100"
              }`}
            >
              {item}
            </button>
          ))}

        </div>

      </section>

      {/* Blog List */}
      <section className="container mx-auto px-4 py-16">

        <div className="mb-10 flex items-center justify-between">

          <div>
            <h2 className="text-3xl font-bold">
              Bài viết mới nhất
            </h2>

            <p className="mt-2 text-gray-500">
              {filteredBlogs.length} bài viết
            </p>
          </div>

        </div>

        <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">

          {filteredBlogs.map((blog) => (
            <BlogCard
              key={blog.id}
              blog={blog}
            />
          ))}

        </div>

        {filteredBlogs.length === 0 && (
          <div className="py-20 text-center text-gray-500">
            Không tìm thấy bài viết phù hợp.
          </div>
        )}

      </section>

    </main>
  );
}

export default Blog;