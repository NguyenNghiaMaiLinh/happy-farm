import { Link, useParams } from "react-router-dom";
import {
  CalendarDays,
  Clock3,
  User,
  ChevronRight,
  Facebook,
  Share2,
} from "lucide-react";

import { blogs } from "../data/blogs";

function BlogDetail() {
  const { slug } = useParams();

  const blog = blogs.find((item) => item.slug === slug);

  if (!blog) {
    return (
      <div className="container mx-auto py-24 text-center">
        <h1 className="text-4xl font-bold">
          Không tìm thấy bài viết
        </h1>

        <Link
          to="/blog"
          className="mt-8 inline-block rounded-xl bg-green-700 px-6 py-3 text-white"
        >
          Quay lại Blog
        </Link>
      </div>
    );
  }

  const relatedPosts = blogs
    .filter(
      (item) =>
        item.category === blog.category &&
        item.id !== blog.id
    )
    .slice(0, 3);

  return (
    <main className="bg-gray-50">

      {/* Hero */}

      <section className="relative h-[450px] overflow-hidden">

        <img
          src={blog.image}
          alt={blog.title}
          className="h-full w-full object-cover"
        />

        <div className="absolute inset-0 bg-black/50" />

        <div className="absolute inset-0 flex items-center">

          <div className="container mx-auto px-4 text-white">

            <div className="mb-6 flex items-center gap-2 text-sm">

              <Link to="/">Trang chủ</Link>

              <ChevronRight size={16} />

              <Link to="/blog">Blog</Link>

              <ChevronRight size={16} />

              <span>{blog.category}</span>

            </div>

            <span className="rounded-full bg-green-600 px-4 py-2 text-sm">
              {blog.category}
            </span>

            <h1 className="mt-6 max-w-4xl text-5xl font-bold leading-tight">
              {blog.title}
            </h1>

            <div className="mt-8 flex flex-wrap gap-6 text-green-100">

              <span className="flex items-center gap-2">
                <User size={18} />
                {blog.author}
              </span>

              <span className="flex items-center gap-2">
                <CalendarDays size={18} />
                {blog.date}
              </span>

              <span className="flex items-center gap-2">
                <Clock3 size={18} />
                {blog.readTime}
              </span>

            </div>

          </div>

        </div>

      </section>

      {/* Content */}

      <section className="container mx-auto max-w-5xl px-4 py-16">

        {/* Summary */}

        <div className="mb-12 rounded-3xl border border-green-200 bg-green-50 p-8">

          <h2 className="mb-4 text-2xl font-bold text-green-700">
            📌 Tóm tắt nhanh
          </h2>

          <ul className="space-y-3 text-gray-700">
            <li>✔ Hiểu bản chất của chủ đề.</li>
            <li>✔ Biết cách áp dụng thực tế.</li>
            <li>✔ Tránh các sai lầm phổ biến.</li>
            <li>✔ Chăm sóc cây hiệu quả hơn.</li>
          </ul>

        </div>

        {/* Nội dung */}

        <article className="prose prose-lg max-w-none">

          <h2>Giới thiệu</h2>

          <p>
            {blog.description}
          </p>

          <p>
            Nội dung chi tiết sẽ được mở rộng với hình ảnh,
            bảng biểu, ví dụ thực tế và hướng dẫn từng bước.
            Mỗi bài viết của Happy Farm đều được biên soạn
            nhằm giúp người mới cũng có thể dễ dàng áp dụng.
          </p>

          <h2>Lợi ích</h2>

          <ul>
            <li>Giúp cây phát triển khỏe mạnh.</li>
            <li>Tăng năng suất.</li>
            <li>Tiết kiệm chi phí chăm sóc.</li>
            <li>Cải thiện chất lượng đất.</li>
          </ul>

          <blockquote>
            "Chăm đất trước khi chăm cây" là nguyên tắc quan
            trọng để có một khu vườn bền vững.
          </blockquote>

        </article>

        {/* Share */}

        <div className="mt-16 flex flex-wrap gap-4">

          <button className="flex items-center gap-2 rounded-xl bg-[#1877F2] px-5 py-3 text-white">
            <Facebook size={18} />
            Chia sẻ Facebook
          </button>

          <button className="flex items-center gap-2 rounded-xl bg-green-700 px-5 py-3 text-white">
            <Share2 size={18} />
            Sao chép liên kết
          </button>

        </div>

        {/* Related */}

        {relatedPosts.length > 0 && (
          <section className="mt-20">

            <h2 className="mb-8 text-3xl font-bold">
              Bài viết liên quan
            </h2>

            <div className="grid gap-8 md:grid-cols-3">

              {relatedPosts.map((item) => (
                <Link
                  key={item.id}
                  to={`/blog/${item.slug}`}
                  className="overflow-hidden rounded-3xl bg-white shadow transition hover:-translate-y-2"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-52 w-full object-cover"
                  />

                  <div className="p-6">

                    <h3 className="font-bold">
                      {item.title}
                    </h3>

                    <p className="mt-3 text-sm text-gray-600">
                      {item.description}
                    </p>

                  </div>

                </Link>
              ))}

            </div>

          </section>
        )}

      </section>

    </main>
  );
}

export default BlogDetail;